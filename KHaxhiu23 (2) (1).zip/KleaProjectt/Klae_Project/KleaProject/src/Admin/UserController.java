package Admin;


import Librarian.Users;
import Librarian.MyDate;
import Librarian.AccessLevel;

public class UserController {
	public Users loginn(String firstName, String lastName, String email, MyDate birthday, String password, long salery,
			String phone,AccessLevel accesLevel)
	{
		Users newUser=new Users(firstName,lastName,email,birthday, password,salery,phone,accesLevel);
		
		return newUser;
	}
}
