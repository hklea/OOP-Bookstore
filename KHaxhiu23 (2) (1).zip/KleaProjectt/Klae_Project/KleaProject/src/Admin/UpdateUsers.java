package Admin;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import Librarian.AccessLevel;
import Librarian.MyDate;
import Librarian.Users;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.converter.LongStringConverter;

public class UpdateUsers {

	public static void openStageUpdateUsers(Stage primaryStage) {
		ArrayList<Users> listBooks = new ArrayList<Users>();

		FileInputStream fis;
		try {
			fis = new FileInputStream("Users.dat");
			ObjectInputStream objis = new ObjectInputStream(fis);

			while (objis != null) {

				Users obj = ((Users) objis.readObject());
				listBooks.add(obj);
			}
			objis.close();

		} catch (FileNotFoundException e1) {

		} catch (IOException e1) {

		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		TableView<Users> userTable = new TableView<Users>();
		ObservableList<Users> data = FXCollections.observableArrayList(listBooks);
		userTable.setItems(data);

		// ........................................................................................................
		userTable.setEditable(true);

		// ........................................................................................................

		TableColumn firstName = new TableColumn("First Name");
		TableColumn lastName = new TableColumn("Last Name");
		TableColumn email = new TableColumn("Email");
		TableColumn birthday = new TableColumn("Birthday");
		TableColumn password = new TableColumn("Password");
		TableColumn salery = new TableColumn(" Salery");
		TableColumn phone = new TableColumn(" Phone");
		TableColumn accesLevel = new TableColumn("Acces Level");

		firstName.setCellValueFactory(new PropertyValueFactory<Users, String>("firstName"));
		firstName.setCellFactory(TextFieldTableCell.forTableColumn());
		firstName.setOnEditCommit(new EventHandler<CellEditEvent<Users, String>>() {

			@Override
			public void handle(CellEditEvent<Users, String> event) {

				Users b1 = event.getRowValue();
				b1.setFirstName(event.getNewValue());
				 updateBook(b1);
			}

		});
//		//.........................................................................
//	
		lastName.setCellValueFactory(new PropertyValueFactory<Users, String>("lastName"));
		lastName.setCellFactory(TextFieldTableCell.forTableColumn());
		lastName.setOnEditCommit(new EventHandler<CellEditEvent<Users, String>>() {

			@Override
			public void handle(CellEditEvent<Users, String> event) {

				Users b1 = event.getRowValue();
				b1.setLastName(event.getNewValue());
				 updateBook(b1);
			}

		});
		// .........................................................................
//		
		email.setCellValueFactory(new PropertyValueFactory<Users, String>("email"));
		email.setCellFactory(TextFieldTableCell.forTableColumn());
		email.setOnEditCommit(new EventHandler<CellEditEvent<Users, String>>() {

			@Override
			public void handle(CellEditEvent<Users, String> event) {

				Users b1 = event.getRowValue();
				b1.setEmail(event.getNewValue());
				 updateBook(b1);
			}

		});
//		//.........................................................................
//		
		birthday.setCellValueFactory(new PropertyValueFactory<Users, MyDate>("birthday"));
		birthday.setCellFactory(TextFieldTableCell.forTableColumn(new MyDateStringConverter()));
		birthday.setOnEditCommit(new EventHandler<CellEditEvent<Users, MyDate>>() {

			@Override
			public void handle(CellEditEvent<Users, MyDate> event) {

				Users b1 = event.getRowValue();
				b1.setBirthday(event.getNewValue());

				updateBook(b1);
			}

		});

		password.setCellValueFactory(new PropertyValueFactory<Users, String>("password"));
		password.setCellFactory(TextFieldTableCell.forTableColumn());
		password.setOnEditCommit(new EventHandler<CellEditEvent<Users, String>>() {

			@Override
			public void handle(CellEditEvent<Users, String> event) {

				Users b1 = event.getRowValue();
				b1.setPassword(event.getNewValue());

				 updateBook(b1);
			}

		});

		salery.setCellValueFactory(new PropertyValueFactory<Users, Long>("salery"));
		salery.setCellFactory(TextFieldTableCell.forTableColumn(new LongStringConverter()));
		salery.setOnEditCommit(new EventHandler<CellEditEvent<Users, Long>>() {

			@Override
			public void handle(CellEditEvent<Users, Long> event) {

				Users b1 = event.getRowValue();
				b1.setSalery(event.getNewValue());
				;

				updateBook(b1);
			}

		});

		phone.setCellValueFactory(new PropertyValueFactory<Users, String>("phone"));
		phone.setCellFactory(TextFieldTableCell.forTableColumn());
		phone.setOnEditCommit(new EventHandler<CellEditEvent<Users, String>>() {

			@Override
			public void handle(CellEditEvent<Users, String> event) {

				Users b1 = event.getRowValue();
				b1.setPhone(event.getNewValue());

				updateBook(b1);
			}

		});

		accesLevel.setCellValueFactory(new PropertyValueFactory<Users, AccessLevel>("accesLevel"));
		accesLevel.setCellFactory(TextFieldTableCell.forTableColumn(new AccessLevelStringConverter()));
		accesLevel.setOnEditCommit(new EventHandler<CellEditEvent<Users, AccessLevel>>() {

			@Override
			public void handle(CellEditEvent<Users, AccessLevel> event) {

				Users b1 = event.getRowValue();
				b1.setAccesLevel(event.getNewValue());

				updateBook(b1);
			}

		});

		userTable.getColumns().addAll(firstName, lastName, email, birthday, password, salery, phone, accesLevel);

		Pane pane = new Pane();
		pane.getChildren().addAll(userTable);

		Scene scene = new Scene(pane);
		Stage stage1 = new Stage();

		stage1.setScene(scene);

		stage1.show();

	}

	static ArrayList<Users> newBooks1 = new ArrayList<Users>();

	private static void updateBook(Users b1) {
		FileInputStream fis;
		try {

			fis = new FileInputStream("Users.dat");

			ObjectInputStream objis = new ObjectInputStream(fis);

			while (objis != null) {
				Users obj = ((Users) objis.readObject());
				if (obj.getPassword().equals(b1.getPassword())) {

					obj = b1;
				}
				newBooks1.add(obj);
			}

			objis.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {

			FileOutputStream out;
			try {
				out = new FileOutputStream("Users.dat");
				ObjectOutputStream objout = new ObjectOutputStream(out);
				for (int i = 0; i < newBooks1.size(); i++) {
					objout.writeObject(newBooks1.get(i));
				}
				newBooks1.clear();
				objout.close();

			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				System.out.println("u kryy ");
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
