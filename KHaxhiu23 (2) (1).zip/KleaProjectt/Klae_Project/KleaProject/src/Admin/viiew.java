package Admin;

import Librarian.LogIn;
import Manager.ManagerView;
import Manager.MenagerStatistic;
import Manager.UpdateBook;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class viiew {
	 public static void Adminview(Stage stage) {
	        Button button1 = new Button("Get Data ");
	        Button button2 = new Button("Database");
	        Button button3 = new Button("Sign out ");
	        
	        Label label=new Label("Lets  get started. Select :");
	        
	        button1.setOnAction(e -> {
	        	createUsers.openAdministratorStage(stage);
	      
	        });
	        
	        button2.setOnAction(e -> {
	       
	        	UpdateUsers.openStageUpdateUsers(stage);
	        });
	        
	        button3.setOnAction(e -> {
	      
	        	LogIn.login(stage);
	        });

	        
	        VBox root = new VBox(10,label ,button1, button2, button3);
	        root.setAlignment(Pos.CENTER);
	        Scene scene = new Scene(root, 300, 300);
	        stage.setScene(scene);
	        stage.show();
	    }

}
