package Admin;

import javafx.stage.Stage;
import javafx.util.converter.LongStringConverter;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import Librarian.Users;
import Librarian.MyDate;
import Librarian.AccessLevel;
import Librarian.LogIn;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;


public class createUsers {
	
	public static void openAdministratorStage(Stage primaryStage) {
		
		BorderPane border=new BorderPane();
		
		
		Label First=new Label("First Name");
		TextField tfirst=new TextField();
		Label Last=new Label("Last Name");
		TextField tlast=new TextField();
		Label Email=new Label("Email");
		TextField temail=new TextField();
		Label dateLabel = new Label("Birthdate : ");
		DatePicker dateField = new DatePicker();
		Label Password=new Label("Password");
		TextField tpassword=new TextField();
		Label Phnr=new Label("Phone Number");
		TextField tphone=new TextField();
		Label Salary=new Label("Salary");
		TextField tsalary=new TextField();	
		
		HBox h2=new HBox(30,First,tfirst);
		HBox h3=new HBox(30,Last,tlast);
		HBox h4=new HBox(30,dateLabel,dateField);
		HBox h5=new HBox(60,Email,temail);
		HBox h6=new HBox(10,Phnr,tphone);
		HBox h7 = new HBox(60,Salary,tsalary);
		HBox h8=new HBox(40,Password,tpassword);
		Button btcreate=new Button("Create");
		Button SignOut = new Button("Sign Out");
		HBox h9=new HBox(5,btcreate,SignOut);
		
		SignOut.setOnAction(e->{
			primaryStage.close();
			viiew.Adminview(primaryStage);
		});

		final ToggleGroup group = new ToggleGroup();
		VBox paneForAccess = new VBox(10);
		paneForAccess.setPadding(new Insets(4));
		 
		ArrayList<RadioButton> accessCheckboxes = new ArrayList<>();

		RadioButton bLib = new RadioButton(AccessLevel.LIBRARIAN.toString());
		
		RadioButton bMan = new RadioButton(AccessLevel.MANAGER.toString());
		
		RadioButton bAdmin = new RadioButton(AccessLevel.ADMINISTRATOR.toString());
		

		accessCheckboxes.add(bLib);
		accessCheckboxes.add(bMan);
		accessCheckboxes.add(bAdmin);

		bLib.setToggleGroup(group);
		bMan.setToggleGroup(group);
		bAdmin.setToggleGroup(group);

		paneForAccess.getChildren().addAll(accessCheckboxes);
		
		VBox vbox=new VBox(5,h2,h3,h4,h5,h6,h7,paneForAccess,h8,h9,SignOut);
		//vbox.setAlignment(Pos.CENTER);
		//border.setCenter(vbox);
		border.setCenter(vbox);
		
		UserController newUser = new UserController();
		btcreate.setOnAction(e-> {

			
				AccessLevel ACESS = null;
				for (int i = 0; i < accessCheckboxes.size(); i++) {
					if (accessCheckboxes.get(i).isSelected()) {
						String accesss = accessCheckboxes.get(i).getText();
						if (accesss.equals(AccessLevel.LIBRARIAN.toString())) {
							ACESS = AccessLevel.LIBRARIAN;
						} else if (accesss.equals(AccessLevel.MANAGER.toString())) {
							ACESS = AccessLevel.MANAGER;
						} else {
							ACESS = AccessLevel.ADMINISTRATOR;
						}

					}
				}
				
				Users isCreated = newUser.loginn(tfirst.getText(), tlast.getText(), temail.getText(),
						new MyDate(dateField.getValue().getMonthValue(), dateField.getValue().getDayOfMonth(),
								dateField.getValue().getYear()),
						tpassword.getText(), Integer.parseInt(tsalary.getText()), tphone.getText(),
						ACESS);

				if (isCreated != null) {

					write(isCreated);

				}
				
			});	
		
		
		
		Scene scene=new Scene(border,700,500);
		primaryStage.setTitle("Epokas' Administrator System");
		primaryStage.setScene(scene);
		primaryStage.show();
		
	

	}
		
	
	private static void write(Users isCreated) {

		ArrayList<Users> listBooks = new ArrayList<Users>();

		FileInputStream fis;
		try {

			fis = new FileInputStream("Users.dat");

			ObjectInputStream objis = new ObjectInputStream(fis);

			while (objis != null) {

				Users obj = ((Users) objis.readObject());
				listBooks.add(obj);
			}

			objis.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			listBooks.add(isCreated);
			AddMenuBar(listBooks);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	private static void AddMenuBar(ArrayList<Users> listBooks) {

		FileOutputStream out;
		try {
			out = new FileOutputStream("Users.dat");
			ObjectOutputStream output = new ObjectOutputStream(out);

			for (int i = 0; i < listBooks.size(); i++) {
				output.writeObject(listBooks.get(i));
			}

			output.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("1. " + e);
		}

	}
}





