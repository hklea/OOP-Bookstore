package Admin;

public enum Role {
	 Librarian,Manager,Administrator;

} 
