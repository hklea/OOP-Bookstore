package Librarian;

import java.io.Serializable;
import java.util.ArrayList;

public class Bill implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -136395592495199213L;
	private double price;
    private ArrayList<String> bookNames;
    private MyDate date;
    private int bookQuantity;
    private String librarianName;
    
    public Bill(double price, MyDate date ) {
        this.price = price;
     
        this.date = date;
   
       
    
    }
    
    // getters and setters
    public double getPrice() {
        return price;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
    
    public ArrayList<String> getBookNames() {
        return bookNames;
    }
    
    public void setBookNames(ArrayList<String> bookNames) {
        this.bookNames = bookNames;
    }
    
    public MyDate getDate() {
        return date;
    }
    
    public void setDate(MyDate date) {
        this.date = date;
    }
    

    
    public int getBookQuantity() {
        return bookQuantity;
    }
    
    public void setBookQuantity(int bookQuantity) {
        this.bookQuantity = bookQuantity;
    }
    
    public String getLibrarianName() {
        return librarianName;
    }
    
    public void setLibrarianName(String librarianName) {
        this.librarianName = librarianName;
    }
}