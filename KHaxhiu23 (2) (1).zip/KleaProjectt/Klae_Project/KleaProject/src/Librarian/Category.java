package Librarian;

public enum Category {
	  Action,Fantasy,Novel,Historical,FairyTales;

}