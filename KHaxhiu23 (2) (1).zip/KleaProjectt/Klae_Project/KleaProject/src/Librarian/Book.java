package Librarian;


import java.io.Serializable;
import java.util.ArrayList;



public class Book implements Serializable {
	
	private static final long serialVersionUID = 5296705482940410483L;
	private String title;
	private String ISBN;
	private int quanity;
	private String description;
	private double price;
	private Author author;
	private ArrayList<Category> genres = new ArrayList<>();
	private String genresS;
	private boolean paperback; // or e-book
	//private MyDate date;
	public String getGenresS() {
		String s1="";
		for (int i=0;i<getGenres().size();i++)
		{
			s1+=getGenres().get(i)+" ";
		}
		
		return genresS;
	}

	public void setGenresS(String genresS) {
		ArrayList<String> list1 = new ArrayList<>();
		ArrayList<Category> list2 = new ArrayList<>();
		char[] chararr = genresS.toCharArray();
		String s2="";
		for(int i=0;i<chararr.length;i++)
		{
			if(chararr[i]!=' ') {
				s2+=chararr[i];
			}
			else {
				list1.add(s2);
				s2="";
				i++;
			}
			
		}
		for(int i=0;i<list1.size();i++)
		{
			if(list1.get(i).equals("Action"))
			{
				list2.add(Category.Action);
			}
			else if(list1.get(i).equals("Fantasy"))
			{
				list2.add(Category.Fantasy);
			}
		}
		setGenres(list2);
	}

	
	
	public Book()
	{
		
	}
	
	public Book(String title, String ISBN, int quanity, String description, double price, Author author, boolean paperback) {
		super();
		this.title = title;
		this.ISBN = ISBN;
		this.quanity = quanity;
		this.description = description;
		this.price = price;
		this.author = author;
		this.paperback = paperback;
	}
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	public ArrayList<Category> getGenres() {
		return genres;
	}
	public void setGenres(ArrayList<Category> genres) {
		this.genres = genres;
	}
	public boolean isPaperback() {
		return paperback;
	}
	public void setPaperback(boolean paperback) {
		this.paperback = paperback;
	}
	public int getQuanity() {
		return quanity;
	}
	public void setQuanity(int quanity) {
		this.quanity = quanity;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public void addGenres(Category...genres) {
		for(Category genre : genres)
			this.addGenres(genre);
	}
	@Override
	public String toString() {
		return "Zh_Books [ISBN=" + ISBN + ", title=" + title + ", description=" + description + ", price=" + price
				+ ", author=" + author + ", genres=" + genres + ", paperback=" + paperback + ", quanity=" + quanity
				+ "]";
	}
	
	

	
}
