package Librarian;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

public class BookController implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	
	public Book loginn(String title, String isbn, int quanity, String description, double price, Author author,
			boolean paperback)
	{
		 Book newBook=new Book( title,isbn,quanity,description,price,author,paperback);
		
		return newBook;
	}
	

	

}