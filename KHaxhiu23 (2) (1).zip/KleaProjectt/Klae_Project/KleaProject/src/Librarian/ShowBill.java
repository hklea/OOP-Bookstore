package Librarian;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class ShowBill {
	

	static double total = 0;
	static ArrayList<String> listaaa11;
	
	public static void ShowBill(ArrayList<String> lista, ArrayList<Double> lista1, Pane pane2, Stage stage1, 
		Stage stage, ArrayList<String> listaaa2)
	{
		
			listaaa11 = listaaa2;
		
		HBox [] hBoxs = new HBox[lista.size()];
		VBox [] vBoxs = new VBox[lista.size()];
		VBox vBoxs1 = new VBox();
	
			for(int i=0;i<lista.size();i++)
			{
				Label l1 = new Label("Book: "+lista.get(i));				
				Label l2 = new Label("       Price: "+lista1.get(i)+"");
		
				
				hBoxs[i] = new HBox();
				vBoxs[i] = new VBox(); 
				hBoxs[i].getChildren().addAll(l1,l2);
				vBoxs[i].getChildren().add(hBoxs[i]);
			}
			
			 total=0;
		for(int i=0;i<lista.size();i++)
		{
			vBoxs1.getChildren().add(vBoxs[i]);
		total+=lista1.get(i);
		}
		vBoxs1.setPadding(new Insets(60, 5, 5, 40));
	
		vBoxs1.setSpacing(12);

    	Button Print = new Button("Print Bill"); 
    	Print.setPrefSize(100, 30);
    	
    	Print.setLayoutX(522);
    	Print.setLayoutY(400);
    	
    	Button Back = new Button("Back");  
    	Back.setPrefSize(100, 30);
    	
    	Back.setLayoutX(522);
    	Back.setLayoutY(435);
    	
    	Button ClearBill = new Button("Clear");  
    	ClearBill.setPrefSize(100, 30);
    	
    	ClearBill.setLayoutX(522);
    	ClearBill.setLayoutY(365);
   
    	DatePicker d = new DatePicker();
		 
		 d.setLayoutX(476);
		 d.setLayoutY(150);

		vBoxs1.setLayoutX(30);
    	vBoxs1.setLayoutY(100);
    	
    	Pane pane = new Pane();
        pane.getChildren().addAll(vBoxs1,Print,Back,d,ClearBill);	
    	Scene scene = new Scene(pane,pane2.getWidth(),pane2.getHeight());
		stage1.setScene(scene);
		stage1.show();
		
		Back.setOnAction(e->{
			
			stage1.close();
			LibrarianView.openLibrarianStage(stage);
		
			});
		
		
		ClearBill.setOnAction(e->{
			lista.clear();
			lista1.clear();
			ShowBill(lista,  lista1,  pane2,  stage1, 
					stage,  listaaa2);
		
			});
		
//		//objecti i controllerit
		BillController newBill = new BillController();

		
		Print.setOnAction(e->{
		
		//therret e funksioniti e controllerit / funksioni krijon bill 		       
   Bill isCreated=newBill.loginn(total,new MyDate(d.getValue().getMonthValue(),d.getValue().getDayOfMonth(),d.getValue().getYear()));
	 isCreated.setBookNames(lista);
	 isCreated.setBookQuantity(lista.size());
	 
		
	 
	 if(isCreated!=null)
	 {
	 
		 write(isCreated);
		 
		 File file = new File("cnt.txt");
		 try {
			Scanner input = new Scanner(file);
			String a = input.next();
			int cnt= Integer.parseInt(a);
			cnt++;
			input.close();

			FileWriter file1 = new FileWriter("cnt.txt");
			file1.write((cnt)+"");
			file1.close();
			PrintWriter pfile = new PrintWriter("Klae_Project/KleaProject/src/Bill"+cnt);
			pfile.write("**************Bill************\n");
			String s1="";
			
			for(int i=0;i<lista.size();i++)
			{
				s1=s1+lista.get(i)+" ";
			}
			pfile.write("Books Taken: "+ s1+"\n");
			pfile.write("Total Price: "+ total+"\n");
			pfile.write("Date"+isCreated.getDate()+"\n");
			pfile.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	 }
		
			});
		
	}

	private static  void write(Bill isCreated){
		

		ArrayList<Bill> listBooks = new ArrayList<Bill>();
		 ObjectInputStream objis;
				FileInputStream fis;
					try {
						
						fis = new FileInputStream("Bills.dat");
				
						objis = new ObjectInputStream(fis);
						
			
				
					while(objis!=null)
					{
						Bill obj = ((Bill) objis.readObject());
					
						listBooks.add(obj);
				
					}

			
					objis.close();
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e) {
						
						listBooks.add(isCreated);
						putInFile(listBooks);
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
			}

	private static void putInFile(ArrayList<Bill> listBooks) {
		FileOutputStream out;
		try {
			out = new FileOutputStream("Bills.dat");
			ObjectOutputStream objout = new ObjectOutputStream(out);
			
			for(int i=0;i<listBooks.size();i++)
			{
				objout.writeObject(listBooks.get(i));
				
			}

			for(int i=0;i<listaaa11.size();i++)
			{
				UpdateBook(listaaa11.get(i));
			}
		listaaa11.clear();
								objout.close();
				
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {

		}
		
	}
	static ArrayList<Book> newBooks1 = new ArrayList<Book>();
	
	private static void UpdateBook(String Isbn) {
		FileInputStream fis;
		try {

			fis = new FileInputStream("Books.dat");
			 ObjectInputStream objis;
			objis = new ObjectInputStream(fis);

		while(objis!=null)
		{
			Book obj = ((Book) objis.readObject());
		if(obj.getISBN().equals(Isbn)) {
			int a = obj.getQuanity();
			a -=1;
			obj.setQuanity(a);
		}
		newBooks1.add(obj);
		}


		objis.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
	
			FileOutputStream out;
			try {
				out = new FileOutputStream("Books.dat");
				ObjectOutputStream objout = new ObjectOutputStream(out);
				for(int i=0;i<newBooks1.size();i++)
				{
					objout.writeObject(newBooks1.get(i));
				}
				newBooks1.clear();
				objout.close();
				
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				System.out.println("Done ");
			}
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}


	}

