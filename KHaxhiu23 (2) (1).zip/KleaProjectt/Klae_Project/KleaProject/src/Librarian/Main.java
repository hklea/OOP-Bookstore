package Librarian;
	
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;


public class Main extends Application  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7758305549682883635L;
	@Override
	public void start(Stage primaryStage) {	
		LogIn.login(primaryStage);
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
