package Librarian;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

import Admin.AdminView;
import Admin.viiew;
import Manager.ManagerView;
import Manager.view;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.Window;



public class LogIn {

	static Users u1 = null;
	
	/*
	 * private static String LIBRARIAN_USERNAME = "l"; private static final String
	 * LIBRARIAN_PASSWORD = "1"; private static final String MANAGER_USERNAME = "m";
	 * private static final String MANAGER_PASSWORD = "2"; private static final
	 * String ADMINISTRATOR_USERNAME = "a"; private static final String
	 * ADMINISTRATOR_PASSWORD = "3";
	 */
	public static void login(Stage primaryStage) {

		VBox loginScreen = new VBox();
		loginScreen.setAlignment(Pos.CENTER);
		loginScreen.setSpacing(10);
		loginScreen.setPadding(new Insets(10));

		// Create the username and password fields
		Label usernameLabel = new Label("Username:");
		TextField usernameField = new TextField();
		Label passwordLabel = new Label("Password:");
		PasswordField passwordField = new PasswordField();
		Button loginButton = new Button("Login");

		loginButton.setOnAction(event -> {
			// Check the username and password
			  FileInputStream fis; 
			  try { 
				  fis = new FileInputStream("Users.dat");
			  System.out.println("lol");
			  ObjectInputStream objis = new ObjectInputStream(fis);
			  
			  Users a = (Users) checkUser(objis, usernameField.getText(),
			  passwordField.getText()); 
			  System.out.println(u1);
			  
			  if (u1 == null) { 
			  showAlert(Alert.AlertType.ERROR, loginScreen.getScene().getWindow(),
					  "Form Error!", "Try Again !!!"); 
			  } else 
			  { if(a.getAccesLevel().equals(AccessLevel.LIBRARIAN)){
			  LibrarianView.openLibrarianStage(primaryStage); } 
			  else if
			  (a.getAccesLevel().equals(AccessLevel.MANAGER)) {
				  view.createButtons(primaryStage); } 
			  else if
			  (a.getAccesLevel().equals(AccessLevel.ADMINISTRATOR)) {
				  viiew.Adminview(primaryStage); }
			  
			  } 
			  } catch (FileNotFoundException e1) { // TODO Auto-generated catch block
			  e1.printStackTrace(); } catch (IOException e1) {
			  
			  }
			
			/*
			 * AccessLevel accessLevel = checkLogin(usernameField.getText(),
			 * passwordField.getText());
			 * 
			 * 
			 * if (accessLevel == AccessLevel.LIBRARIAN) {
			 * LibrarianView.openLibrarianStage(primaryStage); } else if (accessLevel ==
			 * AccessLevel.MANAGER) { ManagerView.openManagerStage(primaryStage); } else if
			 * (accessLevel == AccessLevel.ADMINISTRATOR) {
			 * AdminView.openAdministratorStage(primaryStage); } else { // Display an
			 * errormessage if the login is invalid Alert alert = new
			 * Alert(Alert.AlertType.ERROR, "Invalid username or password!");
			 * alert.showAndWait(); }
			 */
			 
			 
		});

		// Add the login screen components to the scene
		loginScreen.getChildren().addAll(usernameLabel, usernameField, passwordLabel, passwordField, loginButton);
		Scene scene = new Scene(loginScreen, 300, 300);

		// Set the stage and show the scene
		primaryStage.setTitle("BookStore Login");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	private static void showAlert(AlertType error, Window window, String string, String string2) {
		 Alert alert = new Alert(error);
	        alert.setTitle(string);
	        alert.setHeaderText(null);
	        alert.setContentText(string2);
	        alert.initOwner(window);
	        alert.show();
		
	} 

	private static Object checkUser(ObjectInputStream objis, String usernametextFiled, String PassswrdField) {

		while (true) {
			try {
				u1 = ((Users) objis.readObject());
				if (usernametextFiled.equals(u1.getFirstName()) && PassswrdField.equals(u1.getPassword())) {

					return u1;
				} else {

				}

			} catch (ClassNotFoundException | IOException e) {
				u1 = null;
				return null;

			}

		}

	}
	
	
	
	/*
	 * private static AccessLevel checkLogin(String username, String password) { if
	 * (username.equals(LIBRARIAN_USERNAME) && password.equals(LIBRARIAN_PASSWORD))
	 * { return AccessLevel.LIBRARIAN; } else if (username.equals(MANAGER_USERNAME)
	 * && password.equals(MANAGER_PASSWORD)) { return AccessLevel.MANAGER; } else if
	 * (username.equals(ADMINISTRATOR_USERNAME) &&
	 * password.equals(ADMINISTRATOR_PASSWORD)) { return AccessLevel.ADMINISTRATOR;
	 * } else { return null; } }
	 */
	 
	 
}