package Librarian;

import java.io.Serializable;

public class BillController implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2781883868730891260L;

	public Bill loginn(double price,MyDate date)
	{
		Bill newBook=new Bill( price,date);
		
		return newBook;
	}

}
