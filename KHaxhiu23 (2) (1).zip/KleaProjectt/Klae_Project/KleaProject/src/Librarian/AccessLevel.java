package Librarian;

import java.io.Serializable;

public enum AccessLevel implements Serializable {
	LIBRARIAN, MANAGER, ADMINISTRATOR
}
