package Manager;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import Librarian.Book;
import Librarian.Author;
import Librarian.BookController;
import Librarian.Book;
import Librarian.Category;
import Librarian.LogIn;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class ManagerView {
	
	public static void openManagerStage(Stage primaryStage) {
		
		TextField title = new TextField();
		title.setLayoutX(300);
		title.setLayoutY(50);
		Label Ltitle = new Label("Title");
		Ltitle.setLayoutX(250);
		Ltitle.setLayoutY(50);

		TextField ISBN = new TextField();
		ISBN.setLayoutX(300);
		ISBN.setLayoutY(100);
		Label LISBN = new Label("ISBN");
		LISBN.setLayoutX(250);
		LISBN.setLayoutY(100);

		TextField Price = new TextField();
		Price.setLayoutX(300);
		Price.setLayoutY(150);
		Label LPrice = new Label("Price");
		LPrice.setLayoutX(250);
		LPrice.setLayoutY(150);

		TextArea description = new TextArea();
		description.setLayoutX(300);
		description.setLayoutY(220);

		description.setPrefRowCount(2);
		description.setPrefColumnCount(20);

		Label Ldescription = new Label("Description");
		Ldescription.setLayoutX(215);
		Ldescription.setLayoutY(220);

		TextField author = new TextField();
		author.setLayoutX(300);
		author.setLayoutY(280);

		Label Lauthor = new Label("Author");
		Lauthor.setLayoutX(245);
		Lauthor.setLayoutY(280);

		TextField quntity = new TextField();
		quntity.setLayoutX(300);
		quntity.setLayoutY(320);

		Label Lquntity = new Label("Quantity");
		Lquntity.setLayoutX(230);
		Lquntity.setLayoutY(320);

		DatePicker d = new DatePicker();

		d.setLayoutX(400);
		d.setLayoutY(400);

		Button b1 = new Button("Add Book");
		b1.setLayoutX(440);
		b1.setLayoutY(450);

		VBox paneForGenres = new VBox(10);
		paneForGenres.setPadding(new Insets(4));
		ArrayList<CheckBox> genreCheckboxes = new ArrayList<>();
		for (Category g : Category.values()) {
			CheckBox chb = new CheckBox(g.toString());
			genreCheckboxes.add(chb);
			
		}
		
		paneForGenres.getChildren().addAll(genreCheckboxes);

		paneForGenres.setLayoutX(300);
		paneForGenres.setLayoutY(350);

		Label genreLbl = new Label("Genres: ");
		genreLbl.setLayoutX(250);
		genreLbl.setLayoutY(400);
		RadioButton rbPaperback = new RadioButton("Paperback");
		rbPaperback.setLayoutX(300);
		rbPaperback.setLayoutY(180);
		RadioButton rbEbook = new RadioButton("E-book");
		rbEbook.setLayoutX(390);
		rbEbook.setLayoutY(180);
		ToggleGroup group = new ToggleGroup();

		rbPaperback.setToggleGroup(group);
		rbEbook.setToggleGroup(group);

		BookController newBOOK = new BookController();
		b1.setOnAction(e -> {
			ArrayList<Category> newZhner = new ArrayList<>();
			boolean isPaperback = rbPaperback.isSelected();
			String isbn13 = ISBN.getText();
			String titlee = title.getText();
			double price = Double.parseDouble(Price.getText());
			String descriptionn = description.getText();
			String authorr = author.getText();
			boolean isPaperback1 = rbPaperback.isSelected();

			for (int i = 0; i < genreCheckboxes.size(); i++) {
				if (genreCheckboxes.get(i).isSelected())
					newZhner.add(Category.values()[i]);
			}
			Book isCreated = newBOOK.loginn(titlee, isbn13, Integer.parseInt(quntity.getText()), descriptionn,
					price, new Author(authorr), isPaperback1);
			isCreated.setGenres(newZhner);

			if (isCreated != null) {

				write(isCreated);

			} else {
				System.out.println("jklklg");
			}
		});

//			  
//			

		Pane pane = new Pane();
		Button buttonBack = new Button("SignOut");
		buttonBack.setLayoutX(650);
		buttonBack.setLayoutY(450);
		
		buttonBack.setOnAction(e->{
			LogIn.login(primaryStage);
		});

		pane.getChildren().addAll(title, Ltitle, ISBN, LISBN, Price, LPrice, description, Ldescription, Lquntity,
				quntity, author, Lauthor, paneForGenres, genreLbl, rbPaperback, rbEbook, b1, d, buttonBack);


		Scene scene = new Scene(pane, 1000, 700);
		primaryStage.setTitle("Managers System");
		primaryStage.setScene(scene);
		primaryStage.show();

		

	}

	private static void write(Book isCreated) {

		ArrayList<Book> listBooks = new ArrayList<Book>();

		FileInputStream fis;
		try {

			fis = new FileInputStream("Books.dat");

			ObjectInputStream objis = new ObjectInputStream(fis);

			Book obj = new Book();

			while (obj != null) {

				obj = ((Book) objis.readObject());
				listBooks.add(obj);
			}

			objis.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			listBooks.add(isCreated);
			AddMenuBar(listBooks);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void AddMenuBar(ArrayList<Book> listBooks) {

		FileOutputStream out;
		try {
			out = new FileOutputStream("Books.dat");
			ObjectOutputStream output = new ObjectOutputStream(out);

			for (int i = 0; i < listBooks.size(); i++) {
				output.writeObject(listBooks.get(i));
			}

			output.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("1. " + e);
		}

	}

}
