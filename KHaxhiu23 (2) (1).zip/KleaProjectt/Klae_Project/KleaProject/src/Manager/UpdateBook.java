package Manager;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import Librarian.Book;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.converter.BooleanStringConverter;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;
import javafx.util.converter.LongStringConverter;

public class UpdateBook {
		private static String a;
		private static double b;
		private static String c;
		private static int d;
		@SuppressWarnings("unchecked")
		public static void Update_Book_View(Stage stage)
		{
			
			
			
			
			//................................................................................................//
		ArrayList<Book> listBooks = new ArrayList<Book>();
			
			FileInputStream fis;
			try {
				fis = new FileInputStream("Books.dat");
				ObjectInputStream objis = new ObjectInputStream(fis);
			
				
				Book obj = new Book() ;
			while(obj!=null)
			{
				
				obj = ((Book) objis.readObject());
				listBooks.add(obj);
			}
			objis.close();
				
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			TableView<Book> userTable = new TableView<Book>();
			ObservableList<Book> data = FXCollections.observableArrayList(listBooks); 
			userTable.setItems(data);
			
			//........................................................................................................
			userTable.setEditable(true);
			
		//........................................................................................................
		
			TableColumn title = new TableColumn("Title");
			TableColumn ISBN = new TableColumn("ISBN");
			TableColumn quanity = new TableColumn("Quanity");
			TableColumn description = new TableColumn("Description");
			TableColumn price = new TableColumn("Price");
			TableColumn author = new TableColumn(" Author");
			TableColumn paperback = new TableColumn("Paperback");
			TableColumn genres = new TableColumn("Genres");
			TableColumn genresS = new TableColumn("GenresS");
			
			
			title.setCellValueFactory(new PropertyValueFactory<Book, String>("Title"));
			title.setCellFactory(TextFieldTableCell.forTableColumn());
			title.setOnEditCommit(new EventHandler<CellEditEvent<Book,String>>(){

			@Override
				public void handle(CellEditEvent<Book, String> event) {
					
				      Book b1 = event.getRowValue();
				      b1.setTitle(event.getNewValue());
				     updateBook(b1);
				}


			
			});
			//.........................................................................
		
			ISBN.setCellValueFactory(new PropertyValueFactory<Book, String>("ISBN"));
			ISBN.setCellFactory(TextFieldTableCell.forTableColumn());
			ISBN.setOnEditCommit(new EventHandler<CellEditEvent<Book,String>>(){

			@Override
				public void handle(CellEditEvent<Book, String> event) {
					
				 Book b1 = event.getRowValue();
			      b1.setISBN((event.getNewValue()));
			     // updateBook(b1);
				}
			
			});
			//.........................................................................
			
			quanity.setCellValueFactory(new PropertyValueFactory<Book, Integer>("Quanity"));
			quanity.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
			quanity.setOnEditCommit(new EventHandler<CellEditEvent<Book,Integer>>(){

			@Override
				public void handle(CellEditEvent<Book, Integer> event) {
					
				 Book b1 = event.getRowValue();
			      b1.setQuanity(event.getNewValue());
			     updateBook(b1);
				}
			
			});
			//.........................................................................
			
			description.setCellValueFactory(new PropertyValueFactory<Book, String>("Description"));
			description.setCellFactory(TextFieldTableCell.forTableColumn());
			description.setOnEditCommit(new EventHandler<CellEditEvent<Book,String>>(){

			@Override
				public void handle(CellEditEvent<Book, String> event) {
					
				 Book b1 = event.getRowValue();
			      b1.setDescription(event.getNewValue());;
			     updateBook(b1);
				}
			
			});
			price.setCellValueFactory(new PropertyValueFactory<Book, Double>("Price"));
			price.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
			price.setOnEditCommit(new EventHandler<CellEditEvent<Book,Double>>(){

		

			@Override
			public void handle(CellEditEvent<Book, Double> event) {
		
				 Book b1 = event.getRowValue();
			      b1.setPrice(event.getNewValue());
			    //  updateBook(b1);
			}
			
			});
			//.........................................................................
			
			author.setCellValueFactory(new PropertyValueFactory<Book, String>("Author"));
//			author.setCellFactory(TextFieldTableCell.forTableColumn());
//			author.setOnEditCommit(new EventHandler<CellEditEvent<Book,String>>(){
	//
//			@Override
//				public void handle(CellEditEvent<Book, String> event) {
//					
////				 Book b1 = event.getRowValue();
////			      b1.setAuthor(event.getNewValue());;
////			      updateBook(b1);
//				}
//			
//			});
//			//.........................................................................
			
			paperback.setCellValueFactory(new PropertyValueFactory<Book, Boolean>("Paperback"));
			paperback.setCellFactory(TextFieldTableCell.forTableColumn(new BooleanStringConverter()));
			paperback.setOnEditCommit(new EventHandler<CellEditEvent<Book,Boolean>>(){


			@Override
			public void handle(CellEditEvent<Book, Boolean> event) {
				Book b1 = event.getRowValue();
			      b1.setPaperback(event.getNewValue());
			     // updateBook(b1);
				
			}
			
			});
			//.........................................................................
			
			genresS.setCellValueFactory(new PropertyValueFactory<Book, String>("GenresS"));
			genresS.setCellFactory(TextFieldTableCell.forTableColumn());
			genresS.setOnEditCommit(new EventHandler<CellEditEvent<Book,String>>(){

			@Override
				public void handle(CellEditEvent<Book, String> event) {
				Book b1 = event.getRowValue();
			      b1.setGenresS(event.getNewValue());
			   //   updateBook(b1);
			
				}
			
			});

			


		
	        FilteredList<Book> flPerson = new FilteredList(data, p -> true);//Pass the data to a filtered list
	        userTable.setItems(flPerson);//Set the table's items using the filtered list
	    	userTable.getColumns().addAll(title,ISBN,quanity,description,price,author,paperback,genresS);
	    	//........................................................................

	    	

	    	
	    	Pane pane = new Pane();
			pane.getChildren().addAll(userTable);

			Scene scene = new Scene(pane);
			Stage stage1 = new Stage();
	    	
				stage1.setScene(scene);

				stage1.show();
}
		
		static ArrayList<Book> newBooks1 = new ArrayList<Book>();
		private static  void updateBook(Book b1) {
			FileInputStream fis;
			try {

				fis = new FileInputStream("Books.dat");
		
				 ObjectInputStream objis = new ObjectInputStream(fis);

			while(objis!=null)
			{
				Book obj = ((Book) objis.readObject());
			if(obj.getISBN().equals(b1.getISBN())) {
				
				obj=b1;
			}
			newBooks1.add(obj);
			}


			objis.close();
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e) {
		
				FileOutputStream out;
				try {
					out = new FileOutputStream("Books.dat");
					ObjectOutputStream objout = new ObjectOutputStream(out);
					for(int i=0;i<newBooks1.size();i++)
					{
						objout.writeObject(newBooks1.get(i));
					}
					newBooks1.clear();
					objout.close();
					
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					System.out.println("Done");
				}
				
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		}
		
}