package Manager;

import Librarian.LogIn;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class view {
	 public static void createButtons(Stage stage) {
	        Button button1 = new Button("New Book");
	        Button button2 = new Button("Book Data");
	        Button button3 = new Button("Sales Graph");
	        Button button4 = new Button("SignOut");
	        Label labe=new Label("Lets start the day! Select :)");
	        
	        button1.setOnAction(e -> {
	        	ManagerView.openManagerStage(stage);
	      
	        });
	        
	        button2.setOnAction(e -> {
	        	UpdateBook.Update_Book_View(stage);
	
	        });
	        
	        button3.setOnAction(e -> {
	        	MenagerStatistic.Satistic_View(stage);
	      
	        });
	        
	        button4.setOnAction(e -> {
	    			stage.close();
	    			LogIn.login(stage);
	    	
	        });
	        
	        VBox root = new VBox(10,labe,button1, button2, button3, button4);
	        root.setAlignment(Pos.CENTER);
	        Scene scene = new Scene(root, 300, 300);
	        stage.setScene(scene);
	        stage.show();
	    }

}
